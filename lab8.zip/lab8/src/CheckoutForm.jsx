import { useState } from "react";
import { useShop } from "./ShopContext.jsx";

function CheckoutForm({ total, onCancel }) {
  const { currentUser, createOrder } = useShop();
  const [form, setForm] = useState({ name: currentUser?.name || "", phone: "", address: "", paymentMethod: "Thanh toán khi nhận hàng" });
  const [error, setError] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [orderTotal, setOrderTotal] = useState(total);

  const handleChange = (event) => {
    setForm({ ...form, [event.target.name]: event.target.value });
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!form.name.trim() || !form.phone.trim() || !form.address.trim()) {
      setError("Vui lòng nhập đầy đủ thông tin nhận hàng.");
      return;
    }
    if (!/^\d{10,11}$/.test(form.phone.replace(/\s/g, ""))) {
      setError("Số điện thoại không hợp lệ.");
      return;
    }
    setError("");
    setOrderTotal(total);
    createOrder(form);
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <div className="checkout-success">
        <h3>Đặt hàng thành công</h3>
        <p>Cảm ơn {form.name}. Đơn hàng trị giá {Number(orderTotal).toLocaleString("vi-VN")} đ đang được xử lý.</p>
        <button className="btn btn-primary btn-block" onClick={onCancel}>Đóng</button>
      </div>
    );
  }

  return (
    <form className="checkout-form" onSubmit={handleSubmit}>
      <div className="cart-drawer-head">
        <h3>Thanh toán</h3>
        <button type="button" className="icon-btn" onClick={onCancel}>Quay lại</button>
      </div>
      <p className="checkout-total">Tổng thanh toán: <strong>{Number(total).toLocaleString("vi-VN")} đ</strong></p>

      <label className="field">
        <span>Họ và tên</span>
        <input name="name" value={form.name} onChange={handleChange} placeholder="Nguyễn Văn A" />
      </label>
      <label className="field">
        <span>Số điện thoại</span>
        <input name="phone" inputMode="numeric" value={form.phone} onChange={handleChange} placeholder="0912345678" />
      </label>
      <label className="field">
        <span>Địa chỉ nhận hàng</span>
        <textarea name="address" value={form.address} onChange={handleChange} placeholder="Số nhà, đường, quận/huyện" rows={2} />
      </label>
      <label className="field">
        <span>Phương thức thanh toán</span>
        <select className="payment-select" name="paymentMethod" value={form.paymentMethod} onChange={handleChange}>
          <option>Thanh toán khi nhận hàng</option>
          <option>Chuyển khoản ngân hàng</option>
          <option>Thanh toán bằng thẻ</option>
        </select>
      </label>
      {error && <p className="form-error">{error}</p>}
      <button type="submit" className="btn btn-primary btn-block">Xác nhận thanh toán</button>
    </form>
  );
}

export default CheckoutForm;
