import { useState } from "react";
import { Link, Navigate, Route, Routes, useNavigate } from "react-router-dom";
import { useShop } from "./ShopContext.jsx";
import Products from "./Products.jsx";
import ProductDetail from "./ProductDetail.jsx";
import LoginForm from "./LoginForm.jsx";
import RegisterForm from "./RegisterForm.jsx";
import CheckoutForm from "./CheckoutForm.jsx";
import "./App.css";

function formatVND(n) {
  return Number(n || 0).toLocaleString("vi-VN") + " đ";
}

function CartDrawer({ open, onClose }) {
  const { cart, updateCartQty, removeFromCart, cartTotal } = useShop();
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [cartSearch, setCartSearch] = useState("");
  if (!open) return null;
  const visibleCart = cart.filter((item) => {
    const code = item.code || `SP-${String(item.id).padStart(3, "0")}`;
    const query = cartSearch.trim().toLocaleLowerCase("vi-VN");
    return !query || code.toLocaleLowerCase("vi-VN").includes(query) || item.name.toLocaleLowerCase("vi-VN").includes(query);
  });

  return (
    <div className="cart-overlay" onClick={onClose}>
      <div className="cart-drawer" onClick={(e) => e.stopPropagation()}>
        <div className="cart-drawer-head">
          <h3>Giỏ hàng</h3>
          <button className="icon-btn" onClick={onClose}>Đóng</button>
        </div>

        {checkoutOpen ? (
          <CheckoutForm total={cartTotal} onCancel={() => setCheckoutOpen(false)} />
        ) : cart.length === 0 ? (
          <p className="empty-row">Giỏ hàng đang trống.</p>
        ) : (
          <>
            <label className="field cart-search-field">
              <span>Tra cứu trong giỏ bằng mã sản phẩm hoặc tên</span>
              <input type="search" value={cartSearch} onChange={(event) => setCartSearch(event.target.value)} placeholder="VD: SP-001" />
            </label>
            <div className="cart-drawer-list">
              {visibleCart.map((item) => (
                <div className="cart-drawer-item" key={item.id}>
                  <div>
                    <p className="cart-drawer-item-name">{item.name}</p>
                    <p className="cart-drawer-item-size">Mã {item.code || `SP-${String(item.id).padStart(3, "0")}`}</p>
                    <p className="cart-drawer-item-size">Size {item.size || "chưa chọn"}</p>
                    <p className="cart-drawer-item-price">{formatVND(item.price)}</p>
                  </div>
                  <div className="qty-control">
                    <button className="icon-btn" onClick={() => updateCartQty(item.id, item.qty - 1)}>−</button>
                    <span>{item.qty}</span>
                    <button className="icon-btn" onClick={() => updateCartQty(item.id, item.qty + 1)}>+</button>
                  </div>
                  <button className="icon-btn icon-btn-danger" onClick={() => removeFromCart(item.id)}>Xoá</button>
                </div>
              ))}
              {visibleCart.length === 0 && <p className="empty-row">Không tìm thấy sản phẩm trong giỏ.</p>}
            </div>
            <div className="cart-drawer-total">
              <span>Tổng cộng</span>
              <strong>{formatVND(cartTotal)}</strong>
            </div>
            <button className="btn btn-primary btn-block" onClick={() => setCheckoutOpen(true)}>
              Thanh toán
            </button>
          </>
        )}
      </div>
    </div>
  );
}

function NotFound() {
  return (
    <div className="page-narrow status-page">
      <p className="eyebrow">404</p>
      <h1 className="page-title">Không tìm thấy trang</h1>
      <p className="product-detail-desc">Đường dẫn bạn truy cập không tồn tại hoặc đã được thay đổi.</p>
      <Link to="/" className="btn btn-primary">Về trang chủ</Link>
    </div>
  );
}

function AdminRoute() {
  const { isAdmin } = useShop();
  return isAdmin ? <Products /> : <Navigate to="/login" replace />;
}

function App() {
  const { currentUser, isAdmin, logout, cartCount } = useShop();
  const [cartOpen, setCartOpen] = useState(false);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/");
  };

  return (
    <div className="app-shell">
      <header className="navbar">
        <Link to="/" className="brand">STRIDE&amp;CO</Link>

        <nav className="nav-links">
          {!isAdmin && <Link to="/">Trang chủ</Link>}
          {isAdmin && <Link to="/">Quản trị</Link>}
          {!currentUser && <Link to="/login">Đăng nhập</Link>}
          {!currentUser && <Link to="/register">Đăng ký</Link>}
          {currentUser && (
            <button className="nav-link-btn" onClick={handleLogout}>
              Đăng xuất ({currentUser.name})
            </button>
          )}
          <button className="cart-btn" onClick={() => setCartOpen(true)}>
            Giỏ hàng
            {cartCount > 0 && <span className="cart-badge">{cartCount}</span>}
          </button>
        </nav>
      </header>

      <main className="app-body">
        <Routes>
          <Route path="/" element={<Products />} />
          <Route path="/admin" element={<AdminRoute />} />
          <Route path="/product/:id" element={<ProductDetail />} />
          <Route path="/login" element={<LoginForm />} />
          <Route path="/register" element={<RegisterForm />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>

      <footer className="footer">
        <div className="footer-top">
          <div>
            <p className="brand" style={{ cursor: "default" }}>STRIDE&amp;CO</p>
            <p className="footer-tag">Giày dép cho mọi hành trình, mỗi ngày.</p>
          </div>
          <div>
            <p className="footer-heading">Cửa hàng</p>
            <Link className="footer-link" to="/">Trang chủ</Link>
          </div>
          <div>
            <p className="footer-heading">Tài khoản</p>
            {!currentUser && <Link className="footer-link" to="/register">Đăng ký</Link>}
            {!currentUser && <Link className="footer-link" to="/login">Đăng nhập</Link>}
          </div>
          <div>
            <p className="footer-heading">Liên hệ</p>
            <p className="footer-text">hotro@strideandco.vn</p>
            <p className="footer-text">1900 6868</p>
          </div>
        </div>
        <div className="footer-bottom">© {new Date().getFullYear()} Stride&amp;Co. Dự án học tập (lab8).</div>
      </footer>

      <CartDrawer open={cartOpen} onClose={() => setCartOpen(false)} />
    </div>
  );
}

export default App;
