import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useShop } from "./ShopContext.jsx";

function LoginForm() {
  const navigate = useNavigate();
  const { login } = useShop();
  const [formData, setFormData] = useState({ email: "", password: "" });
  const [error, setError] = useState("");

  const handleChange = (event) => {
    setFormData({ ...formData, [event.target.name]: event.target.value });
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    if (!formData.email || !formData.password) {
      setError("Vui lòng nhập đầy đủ email và mật khẩu.");
      return;
    }

    const result = login(formData.email, formData.password);
    if (!result.success) {
      setError(result.message);
      return;
    }

    setError("");
    navigate(result.role === "admin" ? "/admin" : "/");
  };

  return (
    <div className="auth-wrap">
      <form className="auth-card" onSubmit={handleSubmit}>
        <h2>Đăng nhập</h2>
        <p className="auth-sub">Dùng cho quản trị viên hoặc khách hàng đã đăng ký.</p>

        <label className="field">
          <span>Email</span>
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            placeholder="ban@vidu.com"
          />
        </label>

        <label className="field">
          <span>Mật khẩu</span>
          <input
            type="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            placeholder="••••••••"
          />
        </label>

        {error && <p className="form-error">{error}</p>}

        <button type="submit" className="btn btn-primary btn-block">
          Đăng nhập
        </button>

        <p className="auth-hint">
          Quản trị viên demo: {" "}
          <code>admin@strideandco.vn / admin123</code>
        </p>
        <p className="auth-hint">
          Chưa có tài khoản? <Link to="/register">Đăng ký ngay</Link>
        </p>
      </form>
    </div>
  );
}

export default LoginForm;
