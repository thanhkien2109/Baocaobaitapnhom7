import { useMemo, useState } from "react";
import { useShop } from "./ShopContext.jsx";
import ProductCard from "./ProductCard.jsx";

const SHOE_SIZES = ["38.5", "39", "40", "40.5", "41", "42", "42.5", "43", "44", "44.5", "45", "45.5", "46", "47", "47.5", "48.5", "49", "49.5"];
const emptyForm = { name: "", category: "", price: "", stock: "", description: "", image: "", sizes: [] };

function Products() {
  const { products, productsLoading, productsError, isAdmin, accounts, orders, favorites, toggleFavorite, addToCart, addProduct, updateProduct, deleteProduct } = useShop();

  const [filter, setFilter] = useState("Tất cả");
  const [search, setSearch] = useState("");
  const [tab, setTab] = useState("products");
  const [showFavorites, setShowFavorites] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState(null);
  const [formError, setFormError] = useState("");

  const categories = useMemo(
    () => ["Tất cả", ...Array.from(new Set(products.map((p) => p.category)))],
    [products]
  );
  const visible = useMemo(() => {
    const normalizedSearch = search.trim().toLocaleLowerCase("vi-VN");
    return products.filter((product) => {
      const matchesCategory = filter === "Tất cả" || product.category === filter;
      const matchesSearch = !normalizedSearch
        || product.name.toLocaleLowerCase("vi-VN").includes(normalizedSearch)
        || product.category.toLocaleLowerCase("vi-VN").includes(normalizedSearch)
        || `sp-${String(product.id).padStart(3, "0")}`.includes(normalizedSearch);
      return matchesCategory && matchesSearch && (!showFavorites || favorites.includes(product.id));
    });
  }, [favorites, filter, products, search, showFavorites]);

  if (productsLoading) {
    return <div className="page-wide"><p className="status-message">Đang tải sản phẩm...</p></div>;
  }

  const resetForm = () => {
    setForm(emptyForm);
    setEditingId(null);
    setFormError("");
  };

  const startEdit = (product) => {
    setEditingId(product.id);
    setForm({
      name: product.name,
      category: product.category,
      price: String(product.price),
      stock: String(product.stock),
      description: product.description || "",
      image: product.image || "",
      sizes: Array.isArray(product.sizes) ? product.sizes.map(String) : [],
    });
    setFormError("");
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!form.name.trim() || !form.category.trim() || !form.price || !form.stock) {
      setFormError("Vui lòng điền đầy đủ các trường bắt buộc.");
      return;
    }
    const payload = {
      name: form.name.trim(),
      category: form.category.trim(),
      price: Number(form.price),
      stock: Number(form.stock),
      description: form.description.trim(),
      image: form.image.trim(),
      sizes: form.sizes,
    };
    if (editingId) {
      updateProduct(editingId, payload);
    } else {
      addProduct(payload);
    }
    resetForm();
  };

  return (
    <div className="page-wide">
      <section className="hero">
        <div>
          <p className="eyebrow">Bộ sưu tập mới</p>
          <h1 className="page-title hero-title">
            Bước đi
            <br />
            đúng nhịp.
          </h1>
          <p className="hero-copy">
            Giày dép cho mọi hành trình — chọn đôi phù hợp và bắt đầu ngày mới.
          </p>
        </div>
      </section>

      {productsError && <p className="status-message status-error">{productsError} Đang sử dụng dữ liệu dự phòng.</p>}

      {isAdmin && (
        <div className="tabs">
          <button className={`tab ${tab === "products" ? "is-active" : ""}`} onClick={() => setTab("products")}>
            Sản phẩm
          </button>
          <button className={`tab ${tab === "accounts" ? "is-active" : ""}`} onClick={() => setTab("accounts")}>
            Tài khoản khách hàng ({accounts.length})
          </button>
          <button className={`tab ${tab === "orders" ? "is-active" : ""}`} onClick={() => setTab("orders")}>
            Đơn hàng ({orders.length})
          </button>
        </div>
      )}

      {isAdmin && tab === "orders" ? (
        <div className="table-wrap">
          <table className="data-table">
            <thead><tr><th>Mã đơn</th><th>Khách hàng</th><th>Sản phẩm</th><th>Thanh toán</th><th>Tổng tiền</th><th>Ngày đặt</th></tr></thead>
            <tbody>
              {orders.map((order) => (
                <tr key={order.id}>
                  <td>{order.id}</td>
                  <td>{order.name}<br /><small>{order.customerEmail} · {order.phone}</small></td>
                  <td>{order.items.map((item) => `${item.code} ${item.name} x${item.qty} (size ${item.size || "-"})`).join(", ")}</td>
                  <td>{order.paymentMethod}</td>
                  <td>{Number(order.total).toLocaleString("vi-VN")} đ</td>
                  <td>{new Date(order.createdAt).toLocaleString("vi-VN")}</td>
                </tr>
              ))}
              {orders.length === 0 && <tr><td colSpan={6} className="empty-row">Chưa có đơn hàng nào.</td></tr>}
            </tbody>
          </table>
        </div>
      ) : isAdmin && tab === "accounts" ? (
        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Họ và tên</th>
                <th>Email</th>
                <th>Ngày đăng ký</th>
              </tr>
            </thead>
            <tbody>
              {accounts.map((acc) => (
                <tr key={acc.email}>
                  <td>{acc.name}</td>
                  <td>{acc.email}</td>
                  <td>{new Date(acc.registeredAt).toLocaleDateString("vi-VN")}</td>
                </tr>
              ))}
              {accounts.length === 0 && (
                <tr>
                  <td colSpan={3} className="empty-row">
                    Chưa có khách hàng nào đăng ký tài khoản.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      ) : (
        <>
          {isAdmin && (
            <form className="admin-form" onSubmit={handleSubmit}>
              <h3>{editingId ? "Sửa sản phẩm" : "Thêm sản phẩm mới"}</h3>
              <div className="admin-form-grid">
                <label className="field">
                  <span>Tên sản phẩm</span>
                  <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="VD: Air Stride Runner" />
                </label>
                <label className="field">
                  <span>Danh mục</span>
                  <input value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} placeholder="VD: Chạy bộ" />
                </label>
                <label className="field">
                  <span>Giá (đ)</span>
                  <input type="number" min="0" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} placeholder="1890000" />
                </label>
                <label className="field">
                  <span>Tồn kho</span>
                  <input type="number" min="0" value={form.stock} onChange={(e) => setForm({ ...form, stock: e.target.value })} placeholder="24" />
                </label>
                <label className="field">
                  <span>URL ảnh</span>
                  <input type="url" value={form.image} onChange={(e) => setForm({ ...form, image: e.target.value })} placeholder="https://..." />
                </label>
              </div>
              <label className="field size-admin-field">
                <span>Size giày</span>
                <div className="admin-size-options">
                  {SHOE_SIZES.map((shoeSize) => (
                    <label className="admin-size-option" key={shoeSize}>
                      <input
                        type="checkbox"
                        checked={form.sizes.includes(shoeSize)}
                        onChange={(event) => setForm({
                          ...form,
                          sizes: event.target.checked
                            ? [...form.sizes, shoeSize]
                            : form.sizes.filter((size) => size !== shoeSize),
                        })}
                      />
                      <span>{shoeSize}</span>
                    </label>
                  ))}
                </div>
              </label>
              <label className="field">
                <span>Mô tả</span>
                <textarea
                  value={form.description}
                  onChange={(e) => setForm({ ...form, description: e.target.value })}
                  placeholder="Mô tả ngắn về sản phẩm"
                  rows={2}
                />
              </label>

              {formError && <p className="form-error">{formError}</p>}

              <div className="admin-form-actions">
                <button type="submit" className="btn btn-primary">
                  {editingId ? "Lưu thay đổi" : "Thêm sản phẩm"}
                </button>
                {editingId && (
                  <button type="button" className="btn btn-ghost" onClick={resetForm}>
                    Huỷ
                  </button>
                )}
              </div>
            </form>
          )}

          <section className="filters">
            <input
              className="product-search"
              type="search"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Tìm sản phẩm..."
              aria-label="Tìm sản phẩm"
            />
            {!isAdmin && <button className={`chip ${showFavorites ? "is-active" : ""}`} onClick={() => setShowFavorites((shown) => !shown)}>♥ Yêu thích ({favorites.length})</button>}
            {categories.map((c) => (
              <button key={c} className={`chip ${filter === c ? "is-active" : ""}`} onClick={() => setFilter(c)}>
                {c}
              </button>
            ))}
          </section>

          <section className="product-grid">
            {visible.map((p) => (
              <ProductCard
                key={p.id}
                product={p}
                isAdmin={isAdmin}
                isFavorite={favorites.includes(p.id)}
                onToggleFavorite={toggleFavorite}
                onAddToCart={addToCart}
                onEdit={startEdit}
                onDelete={(id) => {
                  deleteProduct(id);
                  if (editingId === id) resetForm();
                }}
              />
            ))}
            {visible.length === 0 && <p className="empty-row">Chưa có sản phẩm trong danh mục này.</p>}
          </section>
        </>
      )}
    </div>
  );
}

export default Products;
