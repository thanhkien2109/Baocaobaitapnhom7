import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useShop } from "./ShopContext.jsx";

function RegisterForm() {
  const navigate = useNavigate();
  const { register } = useShop();
  const [formData, setFormData] = useState({ name: "", email: "", password: "", confirm: "" });
  const [error, setError] = useState("");
  const [done, setDone] = useState(false);

  const handleChange = (event) => {
    setFormData({ ...formData, [event.target.name]: event.target.value });
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    if (!formData.name || !formData.email || !formData.password) {
      setError("Vui lòng điền đầy đủ thông tin.");
      return;
    }
    if (!/^\S+@\S+\.\S+$/.test(formData.email)) {
      setError("Email không hợp lệ.");
      return;
    }
    if (formData.password.length < 6) {
      setError("Mật khẩu cần ít nhất 6 ký tự.");
      return;
    }
    if (formData.password !== formData.confirm) {
      setError("Mật khẩu nhập lại không khớp.");
      return;
    }

    const result = register({ name: formData.name, email: formData.email, password: formData.password });
    if (!result.success) {
      setError(result.message);
      return;
    }

    setError("");
    setDone(true);
  };

  if (done) {
    return (
      <div className="auth-wrap">
        <div className="auth-card">
          <h2>Đăng ký thành công</h2>
          <p className="auth-sub">Chào mừng {formData.name}, bạn có thể đăng nhập ngay bây giờ.</p>
          <button className="btn btn-primary btn-block" onClick={() => navigate("/login")}>
            Đến trang đăng nhập
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="auth-wrap">
      <form className="auth-card" onSubmit={handleSubmit}>
        <h2>Tạo tài khoản</h2>
        <p className="auth-sub">Đăng ký để lưu đơn hàng và giỏ hàng của bạn.</p>

        <label className="field">
          <span>Họ và tên</span>
          <input type="text" name="name" value={formData.name} onChange={handleChange} placeholder="Nguyễn Văn A" />
        </label>

        <label className="field">
          <span>Email</span>
          <input type="email" name="email" value={formData.email} onChange={handleChange} placeholder="ban@vidu.com" />
        </label>

        <label className="field">
          <span>Mật khẩu</span>
          <input
            type="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            placeholder="Tối thiểu 6 ký tự"
          />
        </label>

        <label className="field">
          <span>Nhập lại mật khẩu</span>
          <input type="password" name="confirm" value={formData.confirm} onChange={handleChange} placeholder="Nhập lại mật khẩu" />
        </label>

        {error && <p className="form-error">{error}</p>}

        <button type="submit" className="btn btn-primary btn-block">
          Đăng ký
        </button>

        <p className="auth-hint">
          Đã có tài khoản? <Link to="/login">Đăng nhập</Link>
        </p>
      </form>
    </div>
  );
}

export default RegisterForm;
