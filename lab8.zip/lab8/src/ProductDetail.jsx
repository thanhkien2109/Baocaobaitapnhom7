import { useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { useShop } from "./ShopContext.jsx";

function formatVND(n) {
  return Number(n || 0).toLocaleString("vi-VN") + " đ";
}

const SHOE_SIZES = ["38.5", "39", "40", "40.5", "41", "42", "42.5", "43", "44", "44.5", "45", "45.5", "46", "47", "47.5", "48.5", "49", "49.5"];
const UNAVAILABLE_SIZES = new Set(["38.5", "39", "48.5", "49.5"]);

function ProductDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { products, addToCart } = useShop();
  const [qty, setQty] = useState(1);
  const [size, setSize] = useState("");
  const [sizeError, setSizeError] = useState("");

  const product = products.find((p) => String(p.id) === id);

  if (!product) {
    return (
      <div className="page-narrow">
        <p>Không tìm thấy sản phẩm này.</p>
        <Link to="/" className="btn btn-ghost">
          Về trang chủ
        </Link>
      </div>
    );
  }

  return (
    <div className="page-narrow product-detail">
      <Link to="/" className="back-link">
        ← Quay lại danh sách
      </Link>

      <div className="product-detail-layout">
        {product.image && <img className="product-detail-image" src={product.image} alt={product.name} />}

        <div className="product-detail-info">
          <p className="product-card-cat">{product.category}</p>
          <h1 className="page-title">{product.name}</h1>
          <p className="product-detail-price">{formatVND(product.price)}</p>
          <p className="product-detail-desc">{product.description || "Chưa có mô tả cho sản phẩm này."}</p>
          <p className="product-card-stock">Còn {product.stock} đôi trong kho</p>

          <div className="size-field">
            <span>Chọn size</span>
            <div className="size-options">
              {SHOE_SIZES.map((shoeSize) => {
                const availableSizes = Array.isArray(product.sizes) && product.sizes.length > 0 ? product.sizes.map(String) : null;
                const unavailable = availableSizes ? !availableSizes.includes(shoeSize) : UNAVAILABLE_SIZES.has(shoeSize);
                return (
                  <button
                    type="button"
                    key={shoeSize}
                    className={`size-option ${size === shoeSize ? "is-selected" : ""}`}
                    disabled={unavailable}
                    onClick={() => { setSize(shoeSize); setSizeError(""); }}
                  >
                    {shoeSize}
                  </button>
                );
              })}
            </div>
          </div>
          {sizeError && <p className="form-error">{sizeError}</p>}

          <div className="qty-row">
            <div className="qty-control">
              <button className="icon-btn" onClick={() => setQty((q) => Math.max(1, q - 1))}>
                −
              </button>
              <span>{qty}</span>
              <button className="icon-btn" onClick={() => setQty((q) => q + 1)}>
                +
              </button>
            </div>
            <button
              className="btn btn-primary"
              onClick={() => {
                if (!size) {
                  setSizeError("Vui lòng chọn size trước khi thêm vào giỏ.");
                  return;
                }
                addToCart(product, qty, size);
                navigate("/");
              }}
            >
              Thêm vào giỏ
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ProductDetail;
