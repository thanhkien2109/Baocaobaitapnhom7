import { createContext, useContext, useEffect, useState } from "react";

const ShopContext = createContext(null);

export function useShop() {
  return useContext(ShopContext);
}

export const ADMIN_CREDENTIALS = { email: "admin@strideandco.vn", password: "admin123" };

const INITIAL_PRODUCTS = [
  { id: 1, name: "Air Stride Runner", category: "Chạy bộ", price: 1890000, stock: 24, description: "Giày chạy bộ nhẹ, đế êm, thoáng khí cho quãng đường dài.", image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=900&q=85" },
  { id: 2, name: "Urban Trail Boot", category: "Boot", price: 2450000, stock: 12, description: "Boot cổ cao, đế bám tốt, phù hợp đi phố lẫn đi mưa.", image: "https://images.unsplash.com/photo-1520639888713-7851133b1ed0?w=900&q=85" },
  { id: 3, name: "Canvas Low Classic", category: "Thường ngày", price: 990000, stock: 40, description: "Giày vải cổ thấp, phong cách tối giản, dễ phối đồ.", image: "https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?w=900&q=85" },
  { id: 4, name: "Skyline High-Top", category: "Cao cổ", price: 2190000, stock: 18, description: "Giày cổ cao form rộng, đệm gót dày, cá tính đường phố.", image: "https://images.unsplash.com/photo-1607522370275-f14206abe5d3?w=900&q=85" },
  { id: 5, name: "Studio Slide Sandal", category: "Sandal", price: 650000, stock: 33, description: "Sandal quai ngang, chất liệu mềm, thoải mái cả ngày.", image: "https://images.unsplash.com/photo-1603487742131-4160ec999306?w=900&q=85" },
  { id: 6, name: "Featherlight Sneaker", category: "Chạy bộ", price: 2090000, stock: 9, description: "Sneaker siêu nhẹ, hỗ trợ cổ chân tốt cho luyện tập.", image: "https://images.unsplash.com/photo-1552346154-21d32810aba3?w=900&q=85" },
];

function readJSON(storage, key, fallback) {
  try {
    const raw = storage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

function readProducts() {
  const storedProducts = readJSON(localStorage, "sa_products", INITIAL_PRODUCTS);
  return storedProducts.map((product) => {
    const defaultProduct = INITIAL_PRODUCTS.find((item) => item.id === product.id);
    return defaultProduct?.image && !product.image ? { ...product, image: defaultProduct.image } : product;
  });
}

export function ShopProvider({ children }) {
  const [products, setProducts] = useState([]);
  const [productsLoading, setProductsLoading] = useState(true);
  const [productsError, setProductsError] = useState("");
  const [cart, setCart] = useState(() => readJSON(localStorage, "sa_cart", []));
  const [accounts, setAccounts] = useState(() => readJSON(localStorage, "sa_accounts", []));
  const [orders, setOrders] = useState(() => readJSON(localStorage, "sa_orders", []));
  const [favorites, setFavorites] = useState(() => readJSON(localStorage, "sa_favorites", []));
  const [currentUser, setCurrentUser] = useState(() => readJSON(sessionStorage, "sa_current_user", null));

  useEffect(() => {
    let cancelled = false;

    async function loadProducts() {
      try {
        const response = await fetch("/products.json");
        if (!response.ok) throw new Error("Không thể tải sản phẩm.");
        const apiProducts = await response.json();
        const savedProducts = readJSON(localStorage, "sa_products", null);
        if (!cancelled) setProducts(savedProducts ? readProducts() : apiProducts);
      } catch (error) {
        if (!cancelled) {
          setProducts(readProducts());
          setProductsError(error.message || "Không thể tải sản phẩm.");
        }
      } finally {
        if (!cancelled) setProductsLoading(false);
      }
    }

    loadProducts();
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!productsLoading) localStorage.setItem("sa_products", JSON.stringify(products));
  }, [products, productsLoading]);

  useEffect(() => {
    localStorage.setItem("sa_cart", JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem("sa_accounts", JSON.stringify(accounts));
  }, [accounts]);

  useEffect(() => {
    localStorage.setItem("sa_orders", JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem("sa_favorites", JSON.stringify(favorites));
  }, [favorites]);

  useEffect(() => {
    if (currentUser) sessionStorage.setItem("sa_current_user", JSON.stringify(currentUser));
    else sessionStorage.removeItem("sa_current_user");
  }, [currentUser]);

  /* ---------------- Xác thực ---------------- */

  function register({ name, email, password }) {
    if (accounts.some((a) => a.email === email)) {
      return { success: false, message: "Email này đã được đăng ký." };
    }
    const account = { name, email, password, registeredAt: new Date().toISOString() };
    setAccounts((prev) => [...prev, account]);
    return { success: true };
  }

  function login(email, password) {
    if (email === ADMIN_CREDENTIALS.email && password === ADMIN_CREDENTIALS.password) {
      setCurrentUser({ name: "Quản trị viên", email, role: "admin" });
      return { success: true, role: "admin" };
    }
    const account = accounts.find((a) => a.email === email && a.password === password);
    if (account) {
      setCurrentUser({ name: account.name, email: account.email, role: "customer" });
      return { success: true, role: "customer" };
    }
    return { success: false, message: "Email hoặc mật khẩu không đúng." };
  }

  function logout() {
    setCurrentUser(null);
  }

  /* ---------------- Giỏ hàng ---------------- */

  function addToCart(product, qty = 1, size) {
    setCart((prev) => {
      const existing = prev.find((i) => i.id === product.id && i.size === size);
      if (existing) {
        return prev.map((i) => (i.id === product.id && i.size === size ? { ...i, qty: i.qty + qty } : i));
      }
      return [...prev, { id: product.id, name: product.name, price: product.price, size, qty }];
    });
  }

  function updateCartQty(id, qty) {
    if (qty < 1) return;
    setCart((prev) => prev.map((i) => (i.id === id ? { ...i, qty } : i)));
  }

  function removeFromCart(id) {
    setCart((prev) => prev.filter((i) => i.id !== id));
  }

  function clearCart() {
    setCart([]);
  }

  function toggleFavorite(productId) {
    setFavorites((prev) => prev.includes(productId)
      ? prev.filter((id) => id !== productId)
      : [...prev, productId]);
  }

  function createOrder(details) {
    const order = {
      id: `DH-${Date.now()}`,
      ...details,
      customerEmail: currentUser?.email || "Khách vãng lai",
      items: cart.map((item) => ({ ...item, code: item.code || `SP-${String(item.id).padStart(3, "0")}` })),
      total: cart.reduce((sum, item) => sum + item.qty * item.price, 0),
      createdAt: new Date().toISOString(),
    };
    setOrders((prev) => [order, ...prev]);
    clearCart();
    return order;
  }

  const cartCount = cart.reduce((sum, i) => sum + i.qty, 0);
  const cartTotal = cart.reduce((sum, i) => sum + i.qty * i.price, 0);

  /* ---------------- CRUD sản phẩm ---------------- */

  function addProduct(data) {
    setProducts((prev) => [...prev, { id: Date.now(), ...data }]);
  }

  function updateProduct(id, data) {
    setProducts((prev) => prev.map((p) => (p.id === id ? { ...p, ...data } : p)));
  }

  function deleteProduct(id) {
    setProducts((prev) => prev.filter((p) => p.id !== id));
  }

  const value = {
    products,
    productsLoading,
    productsError,
    cart,
    accounts,
    orders,
    favorites,
    currentUser,
    isAdmin: currentUser?.role === "admin",
    register,
    login,
    logout,
    addToCart,
    updateCartQty,
    removeFromCart,
    clearCart,
    toggleFavorite,
    createOrder,
    cartCount,
    cartTotal,
    addProduct,
    updateProduct,
    deleteProduct,
  };

  return <ShopContext.Provider value={value}>{children}</ShopContext.Provider>;
}
