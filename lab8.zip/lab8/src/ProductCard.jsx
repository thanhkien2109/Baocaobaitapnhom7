import { useState } from "react";
import { Link } from "react-router-dom";

function formatVND(n) {
  return Number(n || 0).toLocaleString("vi-VN") + " đ";
}

const SHOE_SIZES = ["38.5", "39", "40", "40.5", "41", "42", "42.5", "43", "44", "44.5", "45", "45.5", "46", "47", "47.5", "48.5", "49", "49.5"];
const UNAVAILABLE_SIZES = new Set(["38.5", "39", "48.5", "49.5"]);

function ProductCard({ product, isAdmin, isFavorite, onToggleFavorite, onAddToCart, onEdit, onDelete }) {
  const [size, setSize] = useState("");
  const [sizeError, setSizeError] = useState("");

  return (
    <article className="product-card">
      <Link to={`/product/${product.id}`} className="product-card-link">
        {product.image && <img className="product-card-image" src={product.image} alt={product.name} />}
        <p className="product-card-code">Mã: SP-{String(product.id).padStart(3, "0")}</p>
        <p className="product-card-cat">{product.category}</p>
        <h3 className="product-card-name">{product.name}</h3>
        <p className="product-card-price">{formatVND(product.price)}</p>
        <p className="product-card-stock">Còn {product.stock} đôi</p>
      </Link>

      <div className="product-card-actions">
        {!isAdmin && <button className={`favorite-btn ${isFavorite ? "is-favorite" : ""}`} onClick={() => onToggleFavorite(product.id)} aria-label={isFavorite ? "Bỏ yêu thích" : "Thêm vào yêu thích"} title={isFavorite ? "Bỏ yêu thích" : "Yêu thích"}>{isFavorite ? "♥" : "♡"}</button>}
        <select
          className="size-select"
          value={size}
          onChange={(event) => { setSize(event.target.value); setSizeError(""); }}
          aria-label={`Chọn size cho ${product.name}`}
        >
          <option value="">Size</option>
          {SHOE_SIZES.map((shoeSize) => (
            <option
              key={shoeSize}
              value={shoeSize}
              disabled={product.sizes?.length ? !product.sizes.map(String).includes(shoeSize) : UNAVAILABLE_SIZES.has(shoeSize)}
            >
              {shoeSize}
            </option>
          ))}
        </select>
        <button className="btn btn-ghost" onClick={() => {
          if (!size) {
            setSizeError("Chọn size");
            return;
          }
          onAddToCart(product, 1, size);
        }}>
          Thêm vào giỏ
        </button>
        {sizeError && <span className="size-error">{sizeError}</span>}

        {isAdmin && (
          <div className="product-card-admin-actions">
            <button className="icon-btn" onClick={() => onEdit(product)} aria-label="Sửa">
              Sửa
            </button>
            <button className="icon-btn icon-btn-danger" onClick={() => onDelete(product.id)} aria-label="Xoá">
              Xoá
            </button>
          </div>
        )}
      </div>
    </article>
  );
}

export default ProductCard;
